package com.fisglobal.service;

import com.fisglobal.signature.DigitalSignature;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
@Service
public class WorldPayService {

    @Autowired
    DigitalSignature digitalSignature;

    public ResponseEntity<String>  payViaAlipay() throws Exception {

        final String uri = "https://open-na.alipay.com/ams/sandbox/api/v1/payments/pay";

        String jsonbody="{\n" +
                "  \"order\": {\n" +
                "    \"env\": {\n" +
                "      \"terminalType\": \"WEB\"\n" +
                "    },\n" +
                "    \"extendInfo\": \"{\\\"chinaExtraTransInfo\\\":{\\\"totalQuantity\\\":\\\"2\\\",\\\"businessType\\\":\\\"4\\\",\\\"goodsInfo\\\":\\\"Macbook 12 inch M3 8G 256G SSD^1|Apple iPad Pro 11 inch^1\\\"}}\",\n" +
                "    \"orderAmount\": {\n" +
                "      \"currency\": \"USD\",\n" +
                "      \"value\": \"100\"\n" +
                "    },\n" +
                "    \"orderDescription\": \"Macbook 12 inch M3 8G 256G SSD^1|Apple iPad Pro 11 inch^1\",\n" +
                "    \"referenceOrderId\": \"alipayCNOrder12345\"\n" +
                "  },\n" +
                "  \"paymentAmount\": {\n" +
                "    \"currency\": \"USD\",\n" +
                "    \"value\": \"100\"\n" +
                "  },\n" +
                "  \"paymentMethod\": {\n" +
                "    \"paymentMethodType\": \"ALIPAY_CN\"\n" +
                "  },\n" +
                "  \"paymentNotifyUrl\": \"http://localhost:8080/\",\n" +
                "  \"paymentRedirectUrl\": \"http://localhost:8080/success\",\n" +
                "  \"paymentRequestId\": \"ams_alipaycn_cashier_pay_sandbox_request_0001\",\n" +
                "  \"productCode\": \"CASHIER_PAYMENT\",\n" +
                "  \"settlementStrategy\": {\n" +
                "    \"settlementCurrency\": \"USD\"\n" +
                "  }\n" +
                "}";
        String body=String.format(jsonbody);
        String path = "/ams/sandbox/api/v1/payments/pay"; //Retrieve the value from the http request line
        String clientId = "SANDBOX_5Y085W2Y3AGY03763"; // The unique ID assigned by Alipay to identify a merchant
        String requestTimeStr = "2020-08-19T21:15:15Z"; //Take the value of Request-Time from header
        String privateKey="MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQCLmR3cCszTAHP7YB976sv7Xs9o5sbEOeMjEUmfoqA1S7VJXZc5KDfw/Xr82kE7/XUCcbPMAmt4iY0nb4Sw0Q9dIHEXyMQ7FeW9pFVYdWksYqoUweG3R8o03F11at12G3bBWfRcF1lsdrgQVfOr2rYA9dAJi1k+I912Wl/hQ4uRHSf0K0PZF9miyyYvzqVnhCrHhhI1WJ0FhLyoIFvbuxbaVCqxOKvqL6uPJjdaqtwNYRd4tHbvO+/dzrWaraOz3MB0E9MJwidjvvG/4KR2TWFdgKOIlSjbM1oVLZDhI7QP2o7mivelG+z22o85uT63mZF2tqo3OVHJ4p3G1cV9a99LAgMBAAECggEAePMLCfFZkZ+c3blkzeqbHYoBznPU14MIJwP9dBBlGogj5BLwyRbtkSEuBBHd32o0jQ+Spjmaf+89m2Nl5gTceOV41xCd5EuOqAbP4zqnC0vY7O8m77OFoNMlLmyOwJv/Ans72uZoFi+uPokZ/FYcxywzOXHAurQ8VyTqWbQ6IlmGX64AVbYYLjIvbXaKiZc4ccq83jUmPetAneRGEXikftt6wegXlaV9738IPHqI/3Ekh59yNiQ/uTWk+LiPIpnKAfTTSFNRH0mUr9blBN8df6WLfSbMNXfvt3aDLQWhYPXjG5lGCtdRPfUyNhTog11kTBwG+DDUuWllSk0geX/1sQKBgQDJTcqru8rWyGjiwELXghhhNkCr6eZnpdAM/bKOwJmDaxhqCjrM1OFfD0dpyHXya4K9hh7vz3dDIr0UYqW+96Cm+mbw2RARxsptpJT2TEL6Jp4IVnZKlIwwjMRSXQVDm1RvXAT11GJ9/aNo5azbYG8LWmyoH5v7smyM2BrOORDnfQKBgQCxhzjbQYLMNYaDYq3X3kosC8LLk+f8WttibjNjvoGELhqpf+Pw5JLNa1WaOMqNF25J91O9r/3+/FhpdNorUt4c+ZqcEbzfBZWmHwMywmiHhMcgYcPKgCmRpSpEWiaB9FMIbIpYii2+HlPCfKonoQrXAPUQT5xXHlThcRF/e65sZwKBgQC5HdNxh7kpOJTTaHBPVDBtPQHN1cNurxmayLYp9k11f8esxAl8kYtK6ncGfTSRoHJTLQJID2YiE9EC7RB0g611wDFn7ISNhFxk5YOi11CET3zmN/SB8wbUIq7q+uW7XR0RZvKcyhlkuRlLfmIuPwj+zMG8/YxospSGFLjZybqU1QKBgQCdeu6c0QhOTkz8z9SW4cG6QNST8qif25kxP8CmgqAxuRQ9uA1j69+uCcDuBeLoNhjH1Hacljoir4deRSIjvGb8HQ9h0vpQfIu7yVb0+C/xx3884nzkbbxyTqmn6LCwJyRhHKe80xawyAZVSHFIpjsPbvH1fimZvnZdZge3puebkQKBgQCkqoHYN6q6ZInol74KIhZ1358Eu+4pAXXYsPBeypl3e2A9EsfUhMHzx8jzWZSJ6Gwzq/jK98cpxSb1gp25z27asYnmyhVcE/HbXyHkn18ZEhtRYm/1sgbRwFQxE+BdkEEBd8p4EHZJ52YN2/GHsnrtr//LFSsqPlrwpq8r4e5kbQ==";
        String programSign= digitalSignature.sign(path,clientId,requestTimeStr,privateKey,jsonbody);
        HttpHeaders httpHeaders =new HttpHeaders();
        httpHeaders.set("Content-Type","application/json; charset=UTF-8");
        httpHeaders.set("Client-Id",clientId);
        httpHeaders.set("Request-Time",requestTimeStr);
        httpHeaders.set("Signature", "algorithm=RSA256,keyVersion=1,signature="+programSign);
        System.out.println(programSign);
        HttpEntity<String> httpEntity= new HttpEntity(body,httpHeaders);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> result = restTemplate.exchange( uri, HttpMethod.POST,httpEntity, String.class);
        System.out.println(result.getBody());
        return result;

    }
}
