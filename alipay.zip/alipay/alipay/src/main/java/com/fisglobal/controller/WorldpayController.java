package com.fisglobal.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fisglobal.service.WorldPayService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.LinkedHashMap;
import java.util.Map;

@RestController
public class WorldpayController {

    @Autowired
    WorldPayService worldPayService;

    @GetMapping("/")
    public ModelAndView pay() throws Exception {
        ModelAndView modelAndView =new ModelAndView();
        ResponseEntity<String> response=worldPayService.payViaAlipay();
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String,Object> responseMap = objectMapper.readValue(response.getBody(),Map.class);
        if(response.getStatusCode().is2xxSuccessful())
        {
            LinkedHashMap<String,Object> resultMap= (LinkedHashMap<String, Object>) responseMap.get("result");
            if(null!=resultMap && resultMap.get("resultCode").equals("PAYMENT_IN_PROCESS"))
            {
                modelAndView.setViewName("walletredirect");
            }
        }
        return modelAndView;
    }

    @GetMapping("/success")
    public String successLandingPage() throws Exception {
        return "Order Placed Successfully";
    }
}
