package com.fisglobal.util;
import javax.xml.bind.DatatypeConverter;


public class DefaultBase64Encryptor implements  Base64Encryptor{
    @Override
    public String encodeToString(byte[] src) {
        return DatatypeConverter.printBase64Binary(src);
    }

    @Override
    public byte[] decode(String src) {
        return DatatypeConverter.parseBase64Binary(src);
    }
}
