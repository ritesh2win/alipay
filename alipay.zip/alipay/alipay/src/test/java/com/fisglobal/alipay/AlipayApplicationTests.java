package com.fisglobal.alipay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlipayApplicationTests {

	@Test
	void contextLoads() {
	}

}
